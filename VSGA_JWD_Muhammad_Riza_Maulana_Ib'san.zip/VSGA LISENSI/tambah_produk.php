<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_produk = $_POST['nama_produk'];
    $harga_produk = $_POST['harga_produk'];
    $gambar_produk = $_POST['gambar_produk']; // Anda dapat mengubah ini sesuai dengan cara mengupload gambar

    $sql = "INSERT INTO produk (nama_produk, harga_produk, gambar_produk) VALUES ('$nama_produk', '$harga_produk', '$gambar_produk')";

    if ($conn->query($sql) === TRUE) {
        echo "Produk berhasil ditambahkan";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <link rel="stylesheet" href="css/home.css">
</head>

<body>
    <h2>Tambah Produk</h2>
    <form action="tambah_produk.php" method="POST">
        <label for="nama_produk">Nama Produk:</label>
        <input type="text" id="nama_produk" name="nama_produk"><br><br>
        <label for="harga_produk">Harga Produk:</label>
        <input type="text" id="harga_produk" name="harga_produk"><br><br>
        <label for="gambar_produk">Gambar Produk:</label>
        <input type="text" id="gambar_produk" name="gambar_produk"><br><br>
        <input type="submit" value="Tambah Produk">
    </form>
</body>

</html>