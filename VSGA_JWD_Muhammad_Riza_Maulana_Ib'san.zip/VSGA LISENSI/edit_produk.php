<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nama_produk = $_POST['nama_produk'];
        $harga_produk = $_POST['harga_produk'];
        $gambar_produk = $_POST['gambar_produk']; // Anda dapat mengubah ini sesuai dengan cara mengupload gambar

        $sql = "UPDATE produk SET nama_produk='$nama_produk', harga_produk='$harga_produk', gambar_produk='$gambar_produk' WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo "Produk berhasil diupdate";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    } else {
        $sql = "SELECT * FROM produk WHERE id='$id'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link rel="stylesheet" href="css/home.css">
</head>

<body>
    <h2>Edit Produk</h2>
    <form action="edit_produk.php?id=<?php echo $row['id']; ?>" method="POST">
        <label for="nama_produk">Nama Produk:</label>
        <input type="text" id="nama_produk" name="nama_produk" value="<?php echo $row['nama_produk']; ?>"><br><br>
        <label for="harga_produk">Harga Produk:</label>
        <input type="text" id="harga_produk" name="harga_produk" value="<?php echo $row['harga_produk']; ?>"><br><br>
        <label for="gambar_produk">Gambar Produk:</label>
        <input type="text" id="gambar_produk" name="gambar_produk" value="<?php echo $row['gambar_produk']; ?>"><br><br>
        <input type="submit" value="Update Produk">
    </form>
</body>

</html>