<?php
include 'koneksi.php';

$sql = "SELECT * FROM produk";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Motor | Produk</title>
    <link rel="stylesheet" href="css/home.css">
</head>

<body>
    <header>
        <!-- Navbar -->
        <div class="hd-container">
            <div class="hd-row">
                <div class="nav-logo">
                    <img src="img/download.png" width="60%" height="70%" />
                </div>
                <div class="nav-title">
                    <h1>MOTORCEL</h1>
                </div>
            </div>
        </div>
        <div class="hd-navbar-container">
            <div class="hd-navbar-row">
                <div class="hd-navbar">
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li><a href="profile.html">Profile</a></li>
                        <li><a href="visimisi.html">Visi dan Misi</a></li>
                        <li><a href="#">Produk Kami</a></li>
                        <li><a href="kontakkami.html">Kontak Kami</a></li>
                        <li><a href="aboutus.html">About Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <!-- Sidebar -->
    <div class="wrap-sbct">
        <div class="sb-container">
            <div class="sb-con-col">
                <div class="sb-list">
                    <ul>
                        <li><a href="artikel.html">Artikel</a></li>
                        <li><a href="event.html">Event</a></li>
                        <li><a href="galeri.html">Gallery Foto</a></li>
                        <li><a href="klien.html">Klien Kami</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Content -->
        <div class="ct-container-vm">
            <div class="ct-title">
                <br>
                <h1>PRODUK MOTORCEL</h1>
                <hr>
            </div>
            <div class="ct-row-pk">
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<div class='ct-image-pk'>";
                        echo "<img src='img/" . $row["gambar_produk"] . "' alt='gambar content' width='300px' height='300px'><br>";
                        echo "<hr><br>";
                        echo "<a href='#'>";
                        echo "<p><b>" . $row["nama_produk"] . "</b></p>";
                        echo "<p>Rp. " . number_format($row["harga_produk"], 2, ',', '.') . "</p>";
                        echo "</a></div>";
                    }
                } else {
                    echo "Tidak ada produk tersedia.";
                }
                $conn->close();
                ?>
            </div>
        </div>
    </div>
    <footer>
        <div>
            <p>&#169; MOTORCEL</p>
        </div>
    </footer>
</body>

</html>